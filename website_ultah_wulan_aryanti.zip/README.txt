WEBSITE ULANG TAHUN WULAN ARYANTI
=================================

File utama: index.html

CARA PREVIEW:
1. Buka index.html di browser yang mendukung file lokal.
2. Untuk menguji foto dan musik, pilih file dari perangkat.
3. Foto/musik yang dipilih lewat tombol di halaman hanya berlaku pada browser/perangkat itu. Agar semua orang yang membuka link melihat foto dan musik, masukkan aset ke website sebelum dipublikasikan.

CATATAN PENTING UNTUK FOTO & MUSIK PUBLIK:
Untuk publikasi, unggah file foto dan audio bersama index.html, lalu ubah bagian galeri dan audio di HTML agar menunjuk ke file tersebut. Jangan unggah foto pribadi jika tidak nyaman foto itu bisa diakses siapa pun yang memiliki link.

HOSTING GRATIS DARI IPHONE (GITHUB PAGES):
1. Buka github.com di Safari dan buat akun/login.
2. Buat repository baru, misalnya wulan-birthday. Pilih Public.
3. Pilih Add file > Upload files (atau buat file baru bernama index.html).
4. Unggah index.html beserta file foto/audio yang ingin dipublikasikan. Jika pakai file foto/audio terpisah, perlu menyesuaikan HTML untuk memanggil file itu.
5. Buka Settings > Pages.
6. Pada Build and deployment pilih Deploy from a branch; pilih branch main dan folder /(root), lalu Save.
7. Tunggu beberapa menit sampai GitHub Pages memberikan alamat website. Buka alamat itu untuk menguji.

MEMBUAT QR CODE:
1. Salin URL publik website.
2. Buka https://www.canva.com/qr-code-generator/ atau https://www.qr-code-generator.com/
3. Masukkan URL website dan buat QR code.
4. Unduh gambar QR, lalu scan menggunakan kamera iPhone lain untuk memastikan link terbuka.
5. Jika isi website diubah tetapi URL tetap sama, QR code biasanya tidak perlu dibuat ulang.

PRIVASI:
Website publik dapat dilihat siapa pun yang memiliki link. Pertimbangkan baik-baik sebelum memasukkan foto pribadi.
